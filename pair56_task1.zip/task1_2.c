/*
  Created by Matthew Bell and Wayne Tsui.
  This programme spins the robot in a circle on the spot. 
*/

#include "simpletools.h"                      
#include "abdrive.h"
#include "robot.h"

int main() {
  while(1) {
    turn_pivot_function(360);  
  }  
}
