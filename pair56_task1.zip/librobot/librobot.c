/*
  Created by Matthew Bell and Wayne Tsui.
*/

#include "simpletools.h"
#include "robot.h"

int main() {
  while(1) {
    turn_pivot_function(360);
  }
}